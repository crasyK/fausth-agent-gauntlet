"""Fausth's strategy: prompts, model ranking and timing for fausth_agent.py.

The runtime (fausth_agent.py) reads everything tunable from this class, so a
change here is a change of strategy, not of plumbing.
"""

from __future__ import annotations

import re

from base_strategy import BaseStrategy, ChallengeContext


class MyStrategy(BaseStrategy):
    agent_id = "fausth"
    agent_name = "Fausth"

    # Text models, best first. Measured on Practice's proxy with
    # bench/bench_models.py (ordering puzzles of 4-8 items); aliases missing
    # from the live roster are skipped, and unknown ones go last.
    text_models = (
        "gemini-3.6-flash",
        "gemini-3.8-flash",
        "qwen3.7-max",
        "nemotron-3-ultra",
        "gpt-5.6-terra",
    )
    # Writes a brute-force program in parallel with the reasoning model; a
    # program that finds exactly one solution is submitted at once.
    program_models = ("gpt-5.4", "gpt-5.6-terra", "qwen3.7-max")
    # Share of the time budget after which a program solution beats waiting
    # for the reasoning model.
    soft_deadline_frac = 0.6
    # When the search finds several solutions, the reasoning model gets this
    # long to pick one before the first solution is submitted.
    ambiguity_grace_s = 8.0
    image_models = (
        "gemini-3.1-flash-image",
        "gemini-3-pro-image",
        "gemini-3.1-flash-lite-image",
    )

    text_temperature = 0.0
    text_max_tokens = 12000
    # Seconds kept back at the end of a challenge for the submit round trip.
    submit_margin_s = 4.0

    text_system_prompt = (
        "You are Fausth, a careful puzzle and reasoning solver in a timed contest. "
        "Work the problem out fully before answering: check every clue or requirement "
        "against your answer. Then reply with exactly one line:\n"
        "ANSWER: <final answer>\n"
        "The final answer must follow the challenge's output rules exactly (order, "
        "separators, capitalisation, JSON shape). Nothing may follow the ANSWER line. "
        "Never answer 'unknown'; give your best answer."
    )

    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        preferred = self.image_models if self.is_image_challenge(ctx) else self.text_models
        ranked = [m for m in preferred if m in available_models]
        if self.is_image_challenge(ctx):
            rest = [m for m in self.prefer_image_models(available_models) if m not in ranked]
        else:
            rest = [m for m in available_models if m not in ranked and "image" not in m]
        return ranked + rest

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        clues = "\n".join(f"- {c}" for c in ctx.clues if c.strip()) or "- (none)"
        parts = [f"Challenge ({ctx.challenge_type or 'text'}): {ctx.description.strip()}"]
        if ctx.rules.strip():
            parts.append(f"Output rules: {ctx.rules.strip()}")
        parts.append(f"Clues:\n{clues}")
        return "\n\n".join(parts)

    def get_llm_params(self, ctx: ChallengeContext) -> dict:
        return {"temperature": self.text_temperature, "max_tokens": self.text_max_tokens}

    # --- images -----------------------------------------------------------

    # Only explicit negations ("no text", "avoid logo/watermark text"), so an
    # instruction that asks for text never gets a no-text constraint.
    _NO_TEXT = re.compile(
        r"\b(?:no|without|avoid\w*)\b[^.;\n]{0,40}?\b(?:text|words|letters|lettering|logos?|watermarks?|captions?)\b",
        re.IGNORECASE,
    )

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        instruction = ctx.rules.strip() or ctx.description.strip()
        lines = [instruction]
        if ctx.description.strip() and ctx.description.strip() not in instruction:
            lines.append(f"Purpose: {ctx.description.strip()}")
        if ctx.image_url:
            lines.append(
                "Change only what the instruction asks. Keep everything else identical to the "
                "input image: the same person or subject, face and features, pose, framing, "
                "camera angle, lighting, colours and background. No style change."
            )
        else:
            lines.append("One coherent, photographic-quality scene with a clean composition.")
        if self._NO_TEXT.search(instruction):
            lines.append(
                "Hard constraint: the image contains no text of any kind. No letters, words, "
                "numbers, logos, watermarks, captions or signatures; signs and screens show "
                "only abstract light and shapes."
            )
        lines.append(
            "Standard resolution only (about 1024 px on the longest side); no HD or 4K."
        )
        return "\n\n".join(lines)
