#!/usr/bin/env python3
"""Fausth: a competitor agent for Agent Gauntlet.

One process per round: register, wait for GO, solve, submit once.

The clock starts when the challenge is fetched, and speed is 15% of the score
(the share of the time limit left at submit), so after GO everything that can
overlap does: clue fetches, the spectator thought, a safety-net model. A
deadline guard submits the best answer in hand before time runs out.
Prompts, models and margins live in my_strategy.py.

Usage (repo root): python fausth_agent.py
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(REPO_ROOT / ".env")

from openai import AsyncOpenAI  # noqa: E402

from arena_clients import (  # noqa: E402
    ArenaAPIError,
    ArenaConnectionError,
    HttpArenaClient,
    McpArenaClient,
    McpArenaError,
    ensure_connected,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
    monitor_session,
    tool_supports_input_property,
)
from arena_clients.config import agent_id_problem  # noqa: E402
from arena_clients.display import challenge_record, save_run_record  # noqa: E402
from arena_clients.outputs import missing_tools_note, save_submitted_image  # noqa: E402
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope  # noqa: E402
from base_strategy import ChallengeContext  # noqa: E402
from model_selector import fetch_available_models  # noqa: E402
from my_strategy import MyStrategy  # noqa: E402

GO_POLL_S = 0.5
# A fallback model only gets a turn when this much time is left.
MIN_RETRY_S = 8.0
MIN_IMAGE_RETRY_S = 25.0
BLANK_PNG_DATA_URI = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7/"
    "S7sAAAAASUVORK5CYII="
)
TEXT_CORE_TOOLS = ("arena.get_challenge", "arena.clues.list", "arena.clues.get")
# The heat sandbox mounts the code read-only; only /tmp is writable.
OUT_ROOT = REPO_ROOT if os.access(REPO_ROOT, os.W_OK) else Path(tempfile.gettempdir())
# Generated programs share the sandbox's 4 GB with the agent, and going over
# ends the run, so each one is capped before it starts.
PROGRAM_MEMORY_BYTES = 1 << 30
PROGRAM_RUNNER = """import resource, runpy, sys
resource.setrlimit(resource.RLIMIT_AS, ({mem}, {mem}))
resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
runpy.run_path(sys.argv[1], run_name="__main__")
"""

_T0 = time.monotonic()


def log(message: str) -> None:
    print(f"[{time.monotonic() - _T0:6.2f}] {message}", flush=True)


# --- answers -----------------------------------------------------------------

_ANSWER_MARK = re.compile(r"^[\s>*_#`]*(?:final\s+)?answer[\s*_`]*:[\s*_`]*", re.IGNORECASE | re.MULTILINE)


def extract_answer(text: str) -> str:
    """The answer after the last ANSWER: marker; JSON answers may span lines."""
    text = re.sub(r"<think>.*?(?:</think>|$)", "", text or "", flags=re.DOTALL).strip()
    marks = list(_ANSWER_MARK.finditer(text))
    if marks:
        rest = text[marks[-1].end():].strip()
    else:
        unfenced = re.sub(r"^```[\w-]*\s*|\s*```$", "", text).strip()
        lines = [line.strip() for line in unfenced.splitlines() if line.strip()]
        if unfenced[:1] in ("{", "["):
            rest = unfenced
        else:
            rest = lines[-1] if len(lines) == 1 and len(lines[0]) < 400 else ""
    rest = re.sub(r"^```[\w-]*\s*|\s*```$", "", rest).strip()
    if rest[:1] not in ("{", "["):
        rest = rest.splitlines()[0].strip() if rest else ""
    answer = rest.strip("*_` ").strip()
    if not answer or answer.lower() in {"unknown", "n/a", "none"} or "<toolcall" in answer.lower():
        return ""
    return answer


# --- model calls ---------------------------------------------------------------


async def ask_model(
    llm: AsyncOpenAI,
    model: str,
    system: str,
    user: str,
    params: dict[str, Any],
    timeout_s: float,
) -> dict[str, Any]:
    started = time.monotonic()
    response = await asyncio.wait_for(
        llm.chat.completions.create(
            model=model,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
            **params,
        ),
        timeout=max(1.0, timeout_s),
    )
    choice = response.choices[0]
    usage = response.usage
    return {
        "model": model,
        "answer": extract_answer(choice.message.content or ""),
        "finish": choice.finish_reason,
        "s": round(time.monotonic() - started, 2),
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
        "raw_tail": (choice.message.content or "")[-300:],
    }


PROGRAM_SYSTEM = (
    "You solve puzzles by writing a short Python 3 program (standard library only). If the task is "
    "a logic, ordering, assignment, scheduling or arithmetic puzzle, the program searches every "
    "candidate exhaustively (itertools.permutations, itertools.product or loops) and checks each "
    "clue literally. It prints every candidate that satisfies all clues, one per line, in the exact "
    "final answer format the rules ask for, and nothing else. Reply with one ```python code block "
    "only. If the task needs knowledge, retrieval, writing or judgement instead of computation, "
    "reply with exactly: SKIP"
)
_SEARCH_HINT = re.compile(r"\bitertools\b|\bpermutations\b|\bproduct\b|\bfor\s+\w+.*\bin\b")


def _norm(answer: str) -> str:
    return re.sub(r"\bteam\s+|\s+", "", answer.lower()).strip(".")


async def run_program(code: str, timeout_s: float) -> list[str]:
    """Run model-written code isolated: temp dir, empty env, no site, hard timeout."""
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "solve.py"
        path.write_text(code, encoding="utf-8")
        runner = Path(tmp) / "runner.py"
        runner.write_text(PROGRAM_RUNNER.format(mem=PROGRAM_MEMORY_BYTES), encoding="utf-8")
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-I", "-S", str(runner), str(path), cwd=tmp, env={},
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
        try:
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=max(0.5, timeout_s))
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return []
    lines: list[str] = []
    for line in out.decode("utf-8", "replace").splitlines():
        if line.strip() and line.strip() not in lines:
            lines.append(line.strip())
    return lines


async def program_lane(llm: AsyncOpenAI, model: str, user: str, deadline: float) -> dict[str, Any]:
    """A fast model writes a brute-force program; its printed solutions come back."""
    started = time.monotonic()
    response = await asyncio.wait_for(
        llm.chat.completions.create(
            model=model,
            messages=[{"role": "system", "content": PROGRAM_SYSTEM}, {"role": "user", "content": user}],
            temperature=0.0, max_tokens=4000),
        timeout=max(1.0, deadline - time.monotonic()))
    text = response.choices[0].message.content or ""
    usage = response.usage
    match = re.search(r"```(?:python)?\s*\n(.*?)```", text, flags=re.DOTALL)
    code = match.group(1) if match else ""
    solutions = await run_program(code, min(10.0, deadline - time.monotonic())) if code else []
    return {
        "model": model, "lane": "program", "skip": text.strip().upper().startswith("SKIP"),
        "searched": bool(_SEARCH_HINT.search(code)), "solutions": solutions[:20],
        "answer": solutions[0] if solutions else "", "s": round(time.monotonic() - started, 2),
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
        "code": code[:4000],
    }


async def solve_text(
    llm: AsyncOpenAI,
    strategy: MyStrategy,
    ranked: list[str],
    program_model: str | None,
    system: str,
    user: str,
    received: float,
    deadline: float,
) -> tuple[str, list[dict[str, Any]]]:
    """Two lanes in parallel: a program that searches, and a model that reasons.

    A program that searched and found exactly one solution is verified, so
    it's submitted at once. Otherwise the reasoning answer wins, picked from
    the program's solutions when it found several; after the soft deadline a
    program solution beats waiting. Failed reasoning falls back down the ranking.
    """
    params = strategy.get_llm_params(None)
    attempts: list[dict[str, Any]] = []
    soft_deadline = min(deadline, received + strategy.soft_deadline_frac * (deadline - received))

    def left() -> float:
        return deadline - time.monotonic()

    def reason(model: str) -> asyncio.Task:
        log(f"reasoning with {model} ({left():.0f}s left)")
        return asyncio.create_task(ask_model(llm, model, system, user, params, left()))

    pending: dict[asyncio.Task, str] = {}
    if program_model:
        log(f"program lane with {program_model}")
        pending[asyncio.create_task(program_lane(llm, program_model, user, deadline))] = "program"
    queue = list(ranked)
    if queue:
        pending[reason(queue.pop(0))] = "reason"
    candidates: list[str] = []
    try:
        while pending:
            wait_until = soft_deadline if candidates else deadline
            done, _ = await asyncio.wait(pending, timeout=max(0.0, wait_until - time.monotonic()),
                                         return_when=asyncio.FIRST_COMPLETED)
            if not done:
                if candidates:
                    log("soft deadline: taking the program's solution")
                    return candidates[0], attempts
                return "", attempts
            for task in done:
                lane = pending.pop(task)
                try:
                    result = task.result()
                except Exception as exc:  # noqa: BLE001 - a failed lane moves on
                    attempts.append({"lane": lane, "error": f"{type(exc).__name__}: {exc}"[:300]})
                    log(f"{lane} lane failed: {type(exc).__name__}: {str(exc)[:120]}")
                    result = None
                if lane == "program":
                    if result is None:
                        continue
                    attempts.append(result)
                    log(f"program: {len(result['solutions'])} solution(s) in {result['s']}s"
                        f"{' (skip)' if result['skip'] else ''}: {result['solutions'][:2]}")
                    if len(result["solutions"]) == 1 and result["searched"]:
                        return result["solutions"][0], attempts
                    candidates = result["solutions"]
                    if len(candidates) > 1 and result["searched"]:
                        # Ambiguous puzzle: reasoning can only pick one of these too.
                        soft_deadline = min(soft_deadline, time.monotonic() + strategy.ambiguity_grace_s)
                    continue
                if result is not None:
                    attempts.append(result)
                    log(f"{result['model']}: {result['answer'][:80]!r} in {result['s']}s "
                        f"({result['completion_tokens']} tokens, {result['finish']})")
                    if result["answer"]:
                        picked = next((c for c in candidates if _norm(c) == _norm(result["answer"])), None)
                        return picked or result["answer"], attempts
                if queue and left() >= MIN_RETRY_S:
                    pending[reason(queue.pop(0))] = "reason"
        return (candidates[0] if candidates else ""), attempts
    finally:
        for task in pending:
            task.cancel()


# --- arena helpers ----------------------------------------------------------------


async def wait_for_go(mcp: McpArenaClient, agent_id: str, modality: str):
    """Poll for the challenge; it stays locked while the lobby is open."""
    waiting = False
    while True:
        try:
            if modality == "image":
                return await mcp.get_image_challenge(agent_id), "image"
            return await mcp.get_challenge(agent_id), "text"
        except McpArenaError as exc:
            message = str(exc).lower()
            if modality == "image" and exc.is_terminal:
                modality = "text"
                continue
            if modality == "text" and "assigned an image" in message:
                modality = "image"
                continue
            if "locked" in message or "waiting for organizer" in message:
                if not waiting:
                    log("lobby open; waiting for GO")
                    waiting = True
                await asyncio.sleep(GO_POLL_S)
                continue
            raise


async def fetch_clues(mcp: McpArenaClient, agent_id: str, fallback: list[str]) -> tuple[list[str], set[str]]:
    """Every clue, fetched in parallel; the payload's clues fill any gap."""
    called: set[str] = set()
    try:
        clue_ids = await mcp.list_clues(agent_id)
        called.add("arena.clues.list")
    except Exception as exc:  # noqa: BLE001
        log(f"clues.list failed: {exc}")
        clue_ids = []
    ids = list(clue_ids) or ["clue_0"]
    results = await asyncio.gather(*(mcp.get_clue(cid, agent_id) for cid in ids), return_exceptions=True)
    called.add("arena.clues.get")
    texts = [r.text.strip() for r in results if not isinstance(r, BaseException) and r.text.strip()]
    merged = list(texts)
    for clue in fallback:
        if clue.strip() and clue.strip() not in merged:
            merged.append(clue.strip())
    return merged, called


def _tool_arguments(tool_def: Any, agent_id: str, query: str) -> dict[str, Any]:
    """Arguments for an unfamiliar tool, filled from its input schema."""
    schema = getattr(tool_def, "inputSchema", None) or {}
    props = schema.get("properties") or {}
    args: dict[str, Any] = {}
    for name, spec in props.items():
        lowered = name.lower()
        if lowered == "agent_id":
            args[name] = agent_id
        elif any(key in lowered for key in ("query", "question", "text", "search", "topic", "q")):
            if (spec or {}).get("type") in (None, "string"):
                args[name] = query
    for name in schema.get("required") or []:
        args.setdefault(name, query)
    return args


async def call_extra_tools(
    mcp: McpArenaClient,
    tool_defs: list[Any],
    names: list[str],
    agent_id: str,
    query: str,
) -> tuple[list[str], set[str]]:
    """Call required tools beyond the clue tools; their output becomes evidence."""
    by_name = {t.name: t for t in tool_defs}
    targets = [n for n in names if n in by_name]

    async def one(name: str) -> tuple[str, str]:
        result = await mcp.call_tool(name, _tool_arguments(by_name[name], agent_id, query))
        return name, json.dumps(result, ensure_ascii=False)[:3000]

    results = await asyncio.gather(*(one(n) for n in targets), return_exceptions=True)
    evidence, called = [], set()
    for name, result in zip(targets, results):
        if isinstance(result, BaseException):
            log(f"{name} failed: {result}")
            continue
        called.add(name)
        evidence.append(f"{result[0]} returned: {result[1]}")
    return evidence, called


def submit_text(http: HttpArenaClient, agent_id: str, answer: str, metrics: dict[str, Any]):
    """Submit once; an exact retry after a lost response returns the same receipt."""
    for attempt in range(3):
        try:
            return http.submit(agent_id=agent_id, answer=answer, client_metrics=metrics)
        except ArenaConnectionError as exc:
            log(f"submit lost ({exc}); retrying the same answer")
            time.sleep(0.5 * (attempt + 1))
        except ArenaAPIError as exc:
            if exc.status_code == 409:
                log("already submitted (409); the first answer stands")
                return None
            raise
    return None


def _record(agent_id: str, record: dict[str, Any]) -> None:
    """Best effort: the kit's run record plus one line per run in outputs/runs.jsonl."""
    save_run_record(agent_id, record, OUT_ROOT)
    try:
        with (OUT_ROOT / "outputs" / "runs.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, default=str) + "\n")
    except Exception:  # noqa: BLE001
        pass


# --- flows ------------------------------------------------------------------------


async def run_text(env: dict[str, Any], challenge) -> None:
    strategy: MyStrategy = env["strategy"]
    http: HttpArenaClient = env["http"]
    mcp: McpArenaClient = env["mcp"]
    agent_id: str = env["agent_id"]
    received = time.monotonic()
    budget_s = float(challenge.time_remaining_s or challenge.max_time_s or 60)
    deadline = received + budget_s - strategy.submit_margin_s
    raw = challenge.raw_data
    required = [str(t) for t in raw.get("required_tools") or []]
    log(f"text challenge {challenge.puzzle_id} · {raw.get('difficulty', '?')} · {budget_s:.0f}s · "
        f"{len(challenge.clues)} clues · required {required}")

    thought = asyncio.create_task(asyncio.to_thread(
        http.broadcast_thought, agent_id,
        f"Fausth is on it: {raw.get('difficulty', '')} {challenge.challenge_type} challenge, reading the clues."))
    scope_task = asyncio.create_task(asyncio.to_thread(http.fetch_usage_scope))
    extra_names = [t for t in required if t not in TEXT_CORE_TOOLS and t != "arena.time_remaining"]
    clues_task = asyncio.create_task(fetch_clues(mcp, agent_id, challenge.clues))
    extra_task = asyncio.create_task(call_extra_tools(
        mcp, env["tool_defs"], extra_names, agent_id, challenge.description or challenge.rules))
    if "arena.time_remaining" in required:
        asyncio.create_task(mcp.time_remaining(agent_id))

    scope = (await scope_task) or resolve_usage_scope()
    clues, called = await clues_task
    evidence, extra_called = await extra_task
    called |= extra_called | {"arena.get_challenge"}

    llm = AsyncOpenAI(
        base_url=get_proxy_host(),
        api_key=get_arena_api_key(),
        default_headers=build_proxy_headers(agent_id, scope),
        max_retries=1,
    )
    available = await env["models_task"]
    ctx = ChallengeContext(
        challenge_type=challenge.challenge_type,
        difficulty=str(raw.get("difficulty", "unknown")),
        challenge_text=challenge.description,
        description=challenge.description,
        rules=challenge.rules,
        clues=clues,
        max_time_s=int(challenge.max_time_s or 0),
        available_models=available,
        required_tools=required,
    )
    ranked = strategy.rank_models(ctx, available)
    user = strategy.build_solver_prompt(ctx)
    extra = challenge.extra_text
    if extra:
        user += f"\n\nOther challenge fields: {extra}"
    if evidence:
        user += "\n\nTool results:\n" + "\n".join(f"- {line}" for line in evidence)

    program_model = next((m for m in strategy.program_models if m in available), None)
    answer, attempts = await solve_text(llm, strategy, ranked, program_model,
                                        strategy.build_system_prompt(ctx), user, received, deadline)
    if not answer:
        answer = next((a.get("raw_tail", "").strip().splitlines()[-1] for a in attempts
                       if a.get("raw_tail", "").strip()), "") or "no answer"
        log(f"no clean answer; submitting fallback {answer[:60]!r}")
    missing = [t for t in required if t not in called]
    if missing:
        log(f"required tools not called: {missing}")
    try:
        await asyncio.wait_for(thought, timeout=max(0.5, deadline - time.monotonic()))
    except Exception as exc:  # noqa: BLE001
        log(f"thought failed: {exc}")

    used = [a for a in attempts if "answer" in a]
    winner = next((a for a in used if a["answer"] == answer), used[0] if used else {})
    if winner.get("lane") == "program" and answer not in winner.get("solutions", []):
        winner = next((a for a in used if a["answer"] and _norm(a["answer"]) == _norm(answer)), winner)
    metrics = {
        "model_name": winner.get("model", ranked[0] if ranked else ""),
        "prompt_tokens": str(sum(a.get("prompt_tokens", 0) for a in used)),
        "completion_tokens": str(sum(a.get("completion_tokens", 0) for a in used)),
        "total_tokens": str(sum(a.get("prompt_tokens", 0) + a.get("completion_tokens", 0) for a in used)),
        "total_time_ms": int((time.monotonic() - received) * 1000),
    }
    log(f"submitting {answer[:80]!r}")
    env["state"]["submitted"] = True
    result = await asyncio.to_thread(submit_text, http, agent_id, answer, metrics)
    score = getattr(result, "score", None) or {}
    log(f"accepted={getattr(result, 'accepted', None)} final={score.get('final_score')} "
        f"quality={score.get('quality_score')} speed={score.get('speed_score')} "
        f"tools={score.get('tools_score')} tokens={score.get('tokens_score')} {missing_tools_note(result)}")
    asyncio.create_task(asyncio.to_thread(http.broadcast_thought, agent_id, f"Fausth submitted: {answer[:120]}"))
    _record(agent_id, {
        "agent_id": agent_id, "at": time.strftime("%Y-%m-%dT%H:%M:%S"), "modality": "text",
        "challenge": challenge_record(challenge), "clues": clues, "evidence": evidence,
        "ranked": ranked, "attempts": attempts, "answer": answer,
        "result": {"accepted": getattr(result, "accepted", None), "score": score},
    })


async def run_image(env: dict[str, Any], challenge) -> None:
    strategy: MyStrategy = env["strategy"]
    http: HttpArenaClient = env["http"]
    mcp: McpArenaClient = env["mcp"]
    agent_id: str = env["agent_id"]
    tool_defs = env["tool_defs"]
    tools = {t.name for t in tool_defs}
    received = time.monotonic()
    budget_s = float(challenge.time_remaining_s or challenge.max_time_s or 120)
    deadline = received + budget_s - strategy.submit_margin_s
    log(f"image challenge {challenge.puzzle_id} · {challenge.challenge_type} · {budget_s:.0f}s")

    thought = asyncio.create_task(mcp.broadcast_image_thought(
        f"Fausth is on it: {challenge.challenge_type} — {challenge.prompt[:100]}", agent_id))
    available = await env["models_task"]
    ctx = ChallengeContext(
        challenge_type=challenge.challenge_type,
        difficulty=challenge.difficulty or "unknown",
        challenge_text=challenge.description,
        description=challenge.description,
        rules="\n".join(p for p in (challenge.prompt, challenge.reference_notes) if p and p.strip()),
        max_time_s=int(challenge.max_time_s or 0),
        available_models=available,
        image_url=challenge.input_image_uri or None,
    )
    ranked = strategy.rank_models(ctx, available)
    prompt = strategy.build_image_prompt(ctx)
    tool = "image_edit" if challenge.input_image_uri and "image_edit" in tools else "image_generate"
    attempts: list[dict[str, Any]] = []
    image_uri = ""
    for i, model in enumerate(ranked or [""]):
        left = deadline - time.monotonic()
        if i and left < MIN_IMAGE_RETRY_S:
            break
        args: dict[str, Any] = {"prompt": prompt, "agent_id": agent_id}
        if tool == "image_edit":
            args["image_uri"] = challenge.input_image_uri
        if model and tool_supports_input_property(tool_defs, tool, "model"):
            args["model"] = model
        log(f"{tool} with {model or 'server default'} ({left:.0f}s left)")
        started = time.monotonic()
        try:
            result = await asyncio.wait_for(mcp.call_tool(tool, args), timeout=max(1.0, left))
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            attempts.append({"model": model, "error": f"{type(exc).__name__}: {exc}"[:300]})
            log(f"{model} failed: {type(exc).__name__}")
            continue
        image_uri = str(result.get("image_uri") or "").strip()
        attempts.append({"model": model, "s": round(time.monotonic() - started, 2),
                         "ok": bool(image_uri), "error": result.get("error")})
        log(f"{model}: {'image' if image_uri else 'no image'} in {attempts[-1]['s']}s {result.get('error') or ''}")
        if image_uri:
            break
    if not image_uri:
        image_uri = challenge.input_image_uri or BLANK_PNG_DATA_URI
        log("no image produced; submitting the fallback")
    try:
        await asyncio.wait_for(thought, timeout=max(0.5, deadline - time.monotonic()))
    except Exception as exc:  # noqa: BLE001
        log(f"thought failed: {exc}")
    winner = next((a for a in attempts if a.get("ok")), {})
    metrics = {"model_name": winner.get("model", ""), "planner_tool": tool,
               "total_time_ms": int((time.monotonic() - received) * 1000)}
    env["state"]["submitted"] = True
    try:
        result = await mcp.submit_image(agent_id=agent_id, image_uri=image_uri, client_metrics=metrics,
                                        rationale=f"Fausth {tool} via {winner.get('model', 'fallback')}")
        score = result.get("score") or {}
        accepted = result.get("accepted")
    except Exception as exc:  # noqa: BLE001 - fall back to the REST submit
        log(f"MCP submit failed ({type(exc).__name__}); submitting over REST")
        rest = await asyncio.to_thread(http.submit, agent_id, image_uri, metrics, "image")
        score, accepted = rest.score or {}, rest.accepted
    log(f"accepted={accepted} final={score.get('final_score')} quality={score.get('quality_score')} "
        f"speed={score.get('speed_score')} judge={ {k: v for k, v in (score.get('judge') or {}).items() if k != 'model'} }")
    save_submitted_image(agent_id, image_uri, OUT_ROOT)
    _record(agent_id, {
        "agent_id": agent_id, "at": time.strftime("%Y-%m-%dT%H:%M:%S"), "modality": "image",
        "challenge": challenge_record(challenge), "prompt": prompt, "tool": tool, "ranked": ranked,
        "attempts": attempts,
        "result": {"accepted": accepted, "score": {k: v for k, v in score.items() if k != "output_image_uri"}},
    })


async def main() -> None:
    strategy = MyStrategy()
    agent_id = (os.getenv("AGENT_ID") or strategy.agent_id).strip()
    agent_name = (os.getenv("AGENT_NAME") or strategy.agent_name).strip()
    problem = agent_id_problem(agent_id)
    if problem:
        raise SystemExit(f"❌ {problem}")
    os.environ["AGENT_ID"] = agent_id
    log(f"{agent_name} ({agent_id}) starting")
    ensure_connected()

    http = HttpArenaClient()
    session = await asyncio.to_thread(http.register, agent_id, agent_name)
    log(f"registered: {session.session_id} ({session.status})")
    monitor = monitor_session(http, agent_id).start()
    models_task = asyncio.create_task(asyncio.to_thread(fetch_available_models, get_proxy_host(), get_arena_api_key()))
    state = {"submitted": False}
    try:
        # After GO a dropped transport is rebuilt, never re-registered.
        for attempt in range(3):
            if state["submitted"]:
                return
            try:
                async with McpArenaClient(get_mcp_url()) as mcp:
                    tool_defs = await mcp.list_tool_defs()
                    tools = [t.name for t in tool_defs]
                    modality = await asyncio.to_thread(McpArenaClient.detect_modality, tools, agent_id)
                    log(f"{len(tools)} tools, modality {modality}")
                    challenge, modality = await wait_for_go(mcp, agent_id, modality)
                    env = {"strategy": strategy, "http": http, "mcp": mcp, "agent_id": agent_id,
                           "tool_defs": tool_defs, "models_task": models_task, "state": state}
                    if modality == "image":
                        await run_image(env, challenge)
                    else:
                        await run_text(env, challenge)
                return
            except (asyncio.CancelledError, KeyboardInterrupt):
                raise
            except McpArenaError:
                raise
            except Exception as exc:  # noqa: BLE001 - transport trouble: reconnect
                log(f"run failed ({type(exc).__name__}: {exc}); reconnecting ({attempt + 1}/3)")
                await asyncio.sleep(0.5)
    finally:
        await monitor.stop()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except asyncio.CancelledError:
        raise SystemExit(0)
